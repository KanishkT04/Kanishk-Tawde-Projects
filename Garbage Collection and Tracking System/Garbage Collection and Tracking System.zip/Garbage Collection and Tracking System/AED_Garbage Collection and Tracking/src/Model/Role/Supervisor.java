/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Role;

/**
 *
 * @author arslanparkar
 */


public class Supervisor {


    private String supervisorId;
    private String name;
    private String password; // Assuming password management

    public Supervisor(String supervisorId, String name, String password) {
        this.supervisorId = supervisorId;
        this.name = name;
        this.password = password;
    }
    
        public String getSupervisorId() {
        return supervisorId;
    }

    public void setSupervisorId(String supervisorId) {
        this.supervisorId = supervisorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    // Getters

}