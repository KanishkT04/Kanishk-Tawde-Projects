
//
//public class DriverController {
//    private DriverDirectory driverDirectory;
//
//    public DriverController(DriverDirectory driverDirectory) {
//        this.driverDirectory = driverDirectory;
//    }
//
//    public Driver addDriver(String driverId, String name, String licenseNumber) {
//        return driverDirectory.createDriver(driverId, name, licenseNumber);
//    }
//
//    public Driver findDriver(String driverId) {
//        return driverDirectory.findDriverById(driverId);
//    }
//}
