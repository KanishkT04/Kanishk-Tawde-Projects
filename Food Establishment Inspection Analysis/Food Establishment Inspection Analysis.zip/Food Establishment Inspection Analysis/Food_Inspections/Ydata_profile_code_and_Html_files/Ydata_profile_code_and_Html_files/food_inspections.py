
# pip install
"""
import pandas as pd
from ydata_profiling import ProfileReport

file_path = "Chicago_2021-2022.tsv"
df = pd.read_csv(file_path, sep='\t')  

profile = ProfileReport(df, explorative=True)
profile.to_file("Chicago_2021-2022_profiling_report.html")
"""

import os
import pandas as pd
from ydata_profiling import ProfileReport

# Get all .tsv files in the current directory
tsv_files = [f for f in os.listdir() if f.endswith('.tsv')]

for file_path in tsv_files:
    print(f"Processing: {file_path}")
    try:
        # Read the TSV file
        df = pd.read_csv(file_path, sep='\t')

        # Create the profile report
        profile = ProfileReport(df, title=f"Profiling Report for {file_path}", explorative=True)

        # Create a new HTML filename
        base_name = os.path.splitext(file_path)[0]  # removes .tsv
        output_file = f"{base_name}_profiling_report.html"

        # Save the report
        profile.to_file(output_file)
        print(f"Report saved as: {output_file}")

    except Exception as e:
        print(f"Error processing {file_path}: {e}")
